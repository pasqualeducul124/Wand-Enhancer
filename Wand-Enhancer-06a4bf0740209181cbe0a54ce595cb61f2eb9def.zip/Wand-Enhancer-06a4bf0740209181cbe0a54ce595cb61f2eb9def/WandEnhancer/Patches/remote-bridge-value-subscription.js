const __wandRemoteTrainerId=${trainerId};
